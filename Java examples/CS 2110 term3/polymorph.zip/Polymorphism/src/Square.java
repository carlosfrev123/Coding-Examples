
public class Square extends Shape {
	public Square(double height) {
		super(height);
	}
	// area of a square is height * height
	// ( a square has the same height and width! )
	// complete this method:
	public double calculateArea() {
		
		// be sure to change the return value
		return 0.0;
	}
	// also create a toString() method!
	/* change this value to return the String
	 * Square with a height of ___ has an area of ___
	 * but fill in the blanks with the actual values
	 */
}
