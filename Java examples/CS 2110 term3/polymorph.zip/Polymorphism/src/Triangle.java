
public class Triangle  extends Shape {
	
	public Triangle (double height) {
		super(height);
	}
	
	// Assume the base of this triangle is equal to its height, ergo area of a triangle is (height * height) / 2

	// create the calculateArea method:
		
	// also create a toString() method!
}
